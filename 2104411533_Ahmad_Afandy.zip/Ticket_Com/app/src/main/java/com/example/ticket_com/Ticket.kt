package com.example.ticket_com

data class Ticket(
    var id: String? = null,
    var destination: String? = null,
    var date: String? = null,
    var price: String? = null
)